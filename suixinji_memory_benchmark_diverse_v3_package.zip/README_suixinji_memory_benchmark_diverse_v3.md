# Suixinji Diverse Memory Benchmark V3

- Cases: **1,000**
- Schema: `suixinji-memory-benchmark-v3.0`
- SHA-256: `37d464b0e2e5c1c7f9df13247b924208817c1bb744b7bdcf3546d7be8def3ca6`

## Diversity

{
  "timeline_note_count": 1474,
  "unique_timeline_text_ratio": 0.8697,
  "unique_query_ratio": 0.4556,
  "min_note_chars": 6,
  "median_note_chars": 16.0,
  "max_note_chars": 79,
  "style_families": [
    "plain",
    "colloquial",
    "formal",
    "ellipsis",
    "markdown",
    "typo",
    "code_switch",
    "self_correction",
    "quoted",
    "temporal",
    "contrast",
    "conditional"
  ],
  "domain_families": [
    "food",
    "technology",
    "city",
    "hobby",
    "project",
    "company",
    "book",
    "task"
  ]
}

## Suites

{
  "atomic_extraction": 100,
  "multiclause_scope": 110,
  "negative_hypothetical_third_party": 90,
  "sensitive_block": 50,
  "task_lifecycle": 150,
  "preference_semantic_change": 130,
  "same_add_source": 70,
  "retrieval_single_hop": 80,
  "complex_retrieval_planning": 70,
  "read_after_write_provisional": 40,
  "deletion_idempotency": 30,
  "cross_user_isolation": 30,
  "session_coreference": 30,
  "adversarial_query_routing": 20
}

## Notes

This set mixes multiple domains, linguistic styles, multi-note timelines, third-party attribution, quotations, hypothetical statements, corrections, temporary states, task lifecycle, retrieval decoys, complex planning, read-after-write, deletion, idempotency, cross-user isolation and session coreference. It is still synthetic and should be reported separately from human-reviewed or online LLM evaluation.
