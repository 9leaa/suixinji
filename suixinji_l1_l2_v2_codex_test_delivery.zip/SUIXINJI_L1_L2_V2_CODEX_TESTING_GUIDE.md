# 随心记 Layer 1 / Layer 2 v2 独立评测执行说明书

> 交付对象：Codex  
> 项目目录：`/home/zcj/suixinji`  
> 数据集版本：
>
> - Layer 1：`suixinji.layer1.independent.v2`
> - Layer 2：`suixinji.layer2.independent.v2`
>
> 本说明书只负责 **Layer 1 和 Layer 2 独立评测**。  
> 不在本轮运行 L1→L2 Bridge、L1→L2→L3 E2E、Layer 3、Worker 全链路或并发专项。

---

# 1. 输入文件

将下列压缩包解压到项目的独立评测数据目录：

```text
eval/datasets/layer1_independent_v2/
eval/datasets/layer2_independent_v2/
```

数据包：

```text
suixinji_layer1_independent_v2.zip
suixinji_layer2_independent_v2.zip
```

解压后主要文件：

```text
manifest.json
schema.json
metrics_contract.md
validation_report.json
datasets/all.jsonl
datasets/<scenario_family>.jsonl
```

数据规模：

```text
Layer 1：420 Cases，14个场景族
Layer 2：400 Cases，16个场景族
```

---

# 2. 全局测试原则

## 2.1 独立层边界

### Layer 1

运行真实生产抽取路径：

```text
原始消息
+ 可选previous_messages
→ Clause / Atom切分
→ Rules
→ LLM
→ Hybrid融合
→ Schema校验
→ MemoryCandidate
```

Layer 1评测到Candidate结束。

禁止：

```text
调用Layer 2归并
查询正式Memory历史
创建Memory / Version / Source
调用Layer 3查询
```

---

### Layer 2

直接使用数据集中的：

```text
input.candidate
```

作为标准Candidate输入，运行真实生产Layer 2路径：

```text
Candidate Retrieval
→ Identity Adjudication
→ Relation Guard
→ Consolidation / Evolution
→ Memory / Version / Source / PendingReview
```

禁止：

```text
重新运行Layer 1抽取
根据原始文本重新构造Candidate
调用Layer 3
```

这样才能确定错误属于Layer 1还是Layer 2。

---

## 2.2 数据集不可修改

不得为了通过测试修改：

```text
case_id
Gold Candidate
Gold Decision
Gold Snapshot
expected status
expected key
expected Source
scenario_family
```

发现数据集与生产契约冲突时：

1. 停止修改生产代码；
2. 输出冲突Case；
3. 说明数据集字段、生产字段和冲突原因；
4. 等待确认是否发布v2.1数据集。

不能在生产代码中读取：

```text
case_id
candidate_ref
m1 / v1 / s1 / pr1
Gold字段
scenario_family
coverage_tags
```

这些都是评测逻辑Ref。

---

## 2.3 不允许特判

禁止：

```text
if case_id == ...
if "随心记第三阶段评测" in text ...
按数据集固定对象名返回结果
把Gold Key注入生产Canonicalizer
按scenario_family选择答案
```

所有修复必须是通用生产逻辑。

---

## 2.4 Task状态v2契约

新生产输出只能包含：

```text
todo
done
```

旧值：

```text
blocked
in_progress
cancelled
canceled
```

只能出现在旧数据读取输入中。

投影规则：

```text
blocked / in_progress → todo
cancelled / canceled → done
```

业务语义必须放入：

```text
blocker
progress_note
closure_reason
```

新Candidate、新Memory、新Version和新持久化结果中出现旧状态，视为硬失败。

---

# 3. 需要实现的评测入口

建议新增：

```text
eval/run_layer1_independent_v2.py
eval/run_layer2_independent_v2.py
```

命令示例：

```bash
python -m eval.run_layer1_independent_v2 \
  --dataset eval/datasets/layer1_independent_v2/datasets/all.jsonl \
  --mode hybrid \
  --output eval/results/layer1_v2_<RUN_ID>

python -m eval.run_layer2_independent_v2 \
  --dataset eval/datasets/layer2_independent_v2/datasets/all.jsonl \
  --backend postgresql \
  --output eval/results/layer2_v2_<RUN_ID>
```

还要支持分桶运行：

```bash
python -m eval.run_layer1_independent_v2 \
  --dataset eval/datasets/layer1_independent_v2/datasets/multi_candidate_mixed.jsonl \
  --mode hybrid \
  --output eval/results/layer1_v2_multi_candidate_<RUN_ID>

python -m eval.run_layer2_independent_v2 \
  --dataset eval/datasets/layer2_independent_v2/datasets/task_reopen_guard.jsonl \
  --backend postgresql \
  --output eval/results/layer2_v2_reopen_guard_<RUN_ID>
```

---

# 4. Layer 1运行要求

## 4.1 必须使用真实抽取入口

优先复用当前生产服务，而不是在Evaluator重新实现抽取规则。

推荐调用顺序：

```text
生产Clause Splitter
→ 生产Atom Builder
→ 生产Rules Extractor
→ 生产LLM Extractor
→ 生产Hybrid Merge
→ 生产Schema Validation
→ 生产Candidate Normalization
```

Evaluator只能：

```text
准备输入
调用生产代码
读取结构化结果
映射并评分
```

---

## 4.2 previous_messages注入

数据集已经提供：

```json
{
  "previous_messages": [
    {
      "note_id": "...",
      "sequence_no": 9,
      "role": "user",
      "text": "...",
      "sensitive": false
    }
  ]
}
```

Evaluator需要构造与生产Inbox查询结果等价的上下文。

必须保持：

```text
同tenant
同space
同user
sequence_no < current sequence_no
最多3条
```

排除：

```text
assistant
bot
system
sensitive=true
```

只有当前消息含有指代信号时，生产代码才能使用previous_messages。

历史消息只能用于解析对象，不能重复抽取历史事实。

---

## 4.3 Layer 1预测文件必须记录

每个Case至少输出：

```json
{
  "case_id": "...",
  "should_store": true,
  "atoms": [],
  "candidates": [],
  "schema_rejected": false,
  "extractor_diagnostics": {
    "clause_count": 0,
    "atom_count": 0,
    "llm_called": false,
    "llm_success": false,
    "llm_candidate_count": 0,
    "rule_candidate_count": 0,
    "final_candidate_count": 0,
    "llm_covered_atom_ids": [],
    "rule_covered_atom_ids": [],
    "final_covered_atom_ids": [],
    "schema_rejected_count": 0,
    "evidence_mapping_rejected_count": 0
  },
  "latency_ms": {
    "clause_split": 0,
    "rules": 0,
    "llm": 0,
    "hybrid_merge": 0,
    "validation": 0,
    "total": 0
  }
}
```

每条预测Candidate建议额外暴露：

```text
atom_id
origin = llm | rules | hybrid
covered_atom_ids
reference_status
antecedent_note_id
resolution_confidence
```

这些是诊断字段，不进入生产持久化契约也可以，但必须来自真实执行过程，不能由Evaluator猜测。

---

# 5. Layer 1 Candidate配对规则

不能继续使用旧版“只要memory_type相同就配对”的宽松方式。

使用一对一最大权重匹配：

```text
Gold Candidate集合
×
Prediction Candidate集合
→ 计算匹配分数
→ 最大权重二分图匹配
```

推荐优先级：

## Task

```text
1. canonical_instance_key完全一致
2. task_family_key一致 + canonical_topic一致
3. memory_type一致 + canonical_topic一致 + Evidence有重叠
```

## Preference

```text
1. preference_assertion_key完全一致
2. preference_family_key一致 + polarity一致 + qualifiers一致
3. memory_type一致 + canonical_topic一致 + polarity一致
```

## Semantic

```text
1. canonical_instance_key完全一致
2. attribute一致 + canonical_topic一致
3. memory_type一致 + Evidence有重叠
```

## Episodic

```text
1. canonical_topic一致 + Evidence Span匹配
2. memory_type一致 + 事件文本高度一致
```

最低配对要求：

```text
memory_type一致
并且至少一个身份、Topic、属性或Evidence信号匹配
```

不能只因为类型一致而强制配对。

匹配算法必须与Candidate顺序无关。

---

# 6. Layer 1指标及公式

## 6.1 Should-store Precision / Recall / F1

正类：

```text
expected.should_store = true
```

公式：

```text
Precision = TP / (TP + FP)
Recall    = TP / (TP + FN)
F1        = 2PR / (P + R)
```

同时输出混淆矩阵。

---

## 6.2 Candidate Precision / Recall / F1

使用第5节的一对一Candidate配对结果。

```text
TP = 成功配对的Candidate数量
FP = 未配对的预测Candidate数量
FN = 未配对的Gold Candidate数量
```

再计算P/R/F1。

需要输出：

```text
Overall Candidate P/R/F1
各memory_type Candidate P/R/F1
各scenario_family Candidate P/R/F1
```

---

## 6.3 Atomic Assertion Recall

只在：

```text
expected.atoms非空
```

的Case计算。

一个Gold Atom被覆盖，需要最终Prediction中至少一条Candidate明确记录该：

```text
atom_id
```

公式：

```text
Atomic Assertion Recall
= 被最终Candidate覆盖的Gold Atom数
/ Gold Atom总数
```

不得只根据Candidate文本猜Atom。

另输出：

```text
Atom Exact Coverage Rate
```

即一个Case中全部Gold Atom都被覆盖的比例。

---

## 6.4 Multi-candidate Recall

只在Gold Candidate数量≥2的Case计算。

```text
Multi-candidate Recall
= 成功配对的Gold Candidate数量
/ Gold Candidate总数
```

同时输出：

```text
Multi-candidate Case Exact
```

一个Case必须满足：

```text
Gold Candidate全部命中
且没有多余Prediction Candidate
```

才算Exact。

---

## 6.5 Multi-preference Split Exact

只计算：

```text
scenario_family = multi_preference_split
```

每个Case必须同时满足：

```text
Candidate数量正确
每个偏好对象正确
polarity正确
preference_assertion_key正确
qualifiers正确
```

否则Case失败。

```text
Split Exact = 完全正确Case / 该分桶全部Case
```

---

## 6.6 Evidence Span指标

主指标使用严格Span口径。

对已经配对的Candidate：

```text
Gold text/start/end
与
Prediction text/start/end
全部相同 → Span TP
```

不相同：

```text
1 Span FP + 1 Span FN
```

未配对Gold：

```text
Span FN
```

未配对Prediction：

```text
Span FP
```

计算：

```text
Evidence Span Precision / Recall / F1
```

还要额外输出诊断指标：

```text
Character-overlap F1
```

但最终主报告以严格Span F1为准。

硬安全要求：

```text
当前Candidate Evidence必须来自current_message
```

Evidence落在previous_messages中，视为硬失败。

---

## 6.7 Memory Type Macro-F1

类别：

```text
task
preference
semantic
episodic
```

使用已配对Candidate的类型预测计算每类P/R/F1，再做宏平均。

同时输出混淆矩阵。

---

## 6.8 Task Binary Status Accuracy

只计算Gold：

```text
memory_type=task
task_status非空
```

正确值只能是：

```text
todo
done
```

```text
Accuracy = task_status预测正确数 / 可评分Task数
```

任意预测旧状态：

```text
blocked / in_progress / cancelled / canceled
```

除了该字段错误外，还触发旧状态输出硬失败。

---

## 6.9 Blocker Accuracy

只计算Gold中：

```text
blocker非空
```

主指标使用规范化Exact Match：

```text
Unicode NFKC
去首尾空白
统一中文标点
压缩连续空白
```

另计算：

```text
Blocker Presence Accuracy
```

用于区分“完全漏字段”和“文字略有差异”。

---

## 6.10 Progress Note Accuracy

只计算Gold中：

```text
progress_note非空
```

计算：

```text
Exact Accuracy
Presence Accuracy
```

---

## 6.11 Closure Reason Accuracy

只计算Gold中：

```text
closure_reason非空
```

固定枚举：

```text
completed
cancelled
abandoned
```

计算Exact Accuracy和混淆矩阵。

---

## 6.12 Polarity Accuracy

只计算Gold：

```text
polarity非空
```

按固定枚举Exact比较。

---

## 6.13 Canonical Instance Key Accuracy

只计算Gold：

```text
canonical_instance_key非空
```

执行轻量规范化：

```text
NFKC
lowercase英文
压缩空白
统一全角半角
去无意义首尾标点
```

不能做语义模糊匹配。

```text
Accuracy = Key完全一致数 / 可评分Gold数
```

分别输出：

```text
Task Instance Key Accuracy
Semantic Instance Key Accuracy
Overall Instance Key Accuracy
```

---

## 6.14 Task Family Key Accuracy

只计算Task且Gold Family Key非空。

Exact比较。

---

## 6.15 Preference Family Key Accuracy

只计算Preference且Gold Family Key非空。

Exact比较。

---

## 6.16 Preference Assertion Key Accuracy

只计算Preference且Gold Assertion Key非空。

Exact比较。

该指标优先于旧版通用Memory Key指标。

---

## 6.17 Qualifier Exact / F1

Qualifier按集合评分，不看顺序。

```text
TP = 预测与Gold交集
FP = 预测多余Qualifier
FN = 漏掉Qualifier
```

计算微平均P/R/F1。

同时计算：

```text
Qualifier Exact-set Accuracy
```

---

## 6.18 Reference Resolution Accuracy

Case级分类：

```text
resolved
unresolved
not_applicable
```

Gold推导规则：

```text
存在Gold Candidate.reference_status=resolved → resolved

scenario_family=reference_resolution_guard
且当前消息包含指代信号
且Gold Candidate为空 → unresolved

其余 → not_applicable
```

Prediction优先读取顶层执行结果；没有顶层字段时读取Candidate。

计算：

```text
Accuracy
Macro-F1
混淆矩阵
```

---

## 6.19 Antecedent Note Accuracy

只在Gold Reference Status为：

```text
resolved
```

时计算。

```text
Accuracy
= antecedent_note_id完全一致数
/ resolved Candidate数
```

---

## 6.20 Antecedent Evidence Span F1

只在resolved Candidate中计算。

主指标仍使用严格：

```text
text/start/end全部一致
```

同时输出Character-overlap F1。

---

## 6.21 Schema Rejected Accuracy

Case级比较：

```text
prediction.schema_rejected
与
expected.schema_rejected
```

计算Accuracy和混淆矩阵。

另外必须统计生产监控事件：

```text
memory.extractor.schema_rejected
```

Gold要求Rejected但没有监控事件，视为可观测性失败。

---

## 6.22 Rules Recovery Recall

该指标依赖真实Hybrid执行诊断。

定义：

```text
D = Gold Atom中未被LLM Candidate覆盖的Atom
N = D中最终被Rules Candidate补齐的Atom
Rules Recovery Recall = N / D
```

若D=0：

```text
该Run该指标记为N/A
```

同时输出：

```text
Hybrid Rule Drop Rate
= Rules发现但LLM未覆盖、最终却被Hybrid丢掉的Gold Atom数
/ Rules发现且LLM未覆盖的Gold Atom数
```

目标为0。

---

# 7. Layer 1建议验收门槛

## 硬门槛

```text
旧Task状态输出数 = 0
Evidence落到previous_messages = 0
跨tenant/space/user读取 = 0
敏感previous_message被使用 = 0
Schema错误静默丢失 = 0
运行异常 = 0
```

## 质量门槛

```text
Should-store F1                  ≥ 0.95
Candidate F1                     ≥ 0.90
Atomic Assertion Recall          ≥ 0.95
Multi-candidate Recall           ≥ 0.90
Multi-preference Split Exact     ≥ 0.90
Evidence Span F1                 ≥ 0.85
Memory Type Macro-F1             ≥ 0.90
Task Binary Status Accuracy      ≥ 0.98
Blocker Presence Accuracy        ≥ 0.95
Progress Note Presence Accuracy  ≥ 0.95
Closure Reason Accuracy          ≥ 0.98
Polarity Accuracy                ≥ 0.98
Task Family Key Accuracy         ≥ 0.90
Preference Assertion Key Acc.    ≥ 0.90
Reference Resolution Macro-F1    ≥ 0.95
Antecedent Note Accuracy         ≥ 0.98
Rules Recovery Recall            ≥ 0.95
```

第一次运行未达到时，先形成真实基线，不得为了过门槛修改Gold。

---

# 8. Layer 2运行要求

## 8.1 后端

正式结果必须使用：

```text
PostgreSQL隔离评测空间
```

每个Case使用独立：

```text
tenant_id
space_id
user_id
```

不得写入用户现有生产空间。

可以先运行SQLite Smoke，但不能用SQLite结果代替正式PostgreSQL结果。

---

## 8.2 Seed方式

将：

```text
input.existing_memories
input.existing_versions
input.existing_sources
```

转换成真实数据库ID后Seed到隔离空间。

逻辑Ref映射：

```text
m1 → actual_memory_uuid
v1 → actual_version_uuid
s1 → actual_source_uuid
pr1 → actual_pending_review_uuid
```

该映射只存在于Evaluator。

生产代码不能读取逻辑Ref。

---

## 8.3 运行生产路径

直接将：

```text
input.candidate
```

映射成生产`MemoryCandidate`，调用真实：

```text
candidate retrieval
identity adjudication
relation guard
consolidator
evolution
repository transaction
```

不得根据Gold Decision直接写数据库。

---

## 8.4 每个Case至少执行三次

### 第一次：正常运行

读取Decision和最终数据库快照。

### 第二次：同一idempotency key重放

验证：

```text
不新增Memory
不新增Version
不重复Source
不重复PendingReview
不重复MemoryDecision
```

### 第三次：只读检查

读取Memory、Version、Source、PendingReview，验证旧状态投影和最终不变量。

---

## 8.5 Layer 2预测文件必须记录

```json
{
  "case_id": "...",
  "retrieved_memory_refs": [],
  "identity_advice": {},
  "decision": {},
  "final_snapshot": {},
  "replay_snapshot": {},
  "invariants": {},
  "latency_ms": {
    "candidate_retrieval": 0,
    "adjudication": 0,
    "relation_guard": 0,
    "transaction": 0,
    "total": 0
  }
}
```

需要暴露：

```text
本地Identity判断
LLM建议
LLM建议是否采纳
Local Guard结果
最终Decision
```

---

# 9. Layer 2逻辑Ref评分

Evaluator需要把真实UUID反向映射回：

```text
m1 / m2
v1 / v2
s1 / s2
pr1
```

只能映射本Case Seed和本次新建对象。

不能从内容或Gold猜测ID。

---

# 10. Layer 2指标及公式

## 10.1 Task Same-instance Precision / Recall / F1

将Task决策二分类：

```text
正类：Gold identity_classification = same_instance
负类：其他Task Identity
```

Prediction为`same_instance`视为预测正类。

计算P/R/F1。

---

## 10.2 Task Family Recall

只在Candidate Task Family Key能够匹配一个或多个Existing Memory Family Key时计算。

Gold Family候选：

```text
existing_memories中family_key与Candidate.task_family_key一致的Memory
```

Prediction：

```text
retrieved_memory_refs
```

```text
Task Family Recall
= 命中的Gold Family Memory数
/ Gold Family Memory总数
```

该指标测Candidate Retrieval，不测最终是否合并。

---

## 10.3 Same-family Over-merge Rate

只计算Gold：

```text
identity_classification = same_family
且Gold预期为新实例
```

错误Over-merge包括：

```text
update现有Memory
add_source到现有Memory
supersede现有Memory
```

公式：

```text
Over-merge Rate
= 被错误合并的same_family Case
/ 全部same_family新实例Case
```

目标为0。

---

## 10.4 Preference Assertion Identity F1

二分类：

```text
正类：same_assertion
负类：same_family / different / uncertain
```

计算P/R/F1。

---

## 10.5 Preference Family Recall

与Task Family Recall相同，但使用：

```text
Candidate.preference_family_key
Existing Memory.family_key
```

---

## 10.6 Relation Macro-F1

类别：

```text
new
same
merge
update
supersede
conflict
```

输出混淆矩阵和Macro-F1。

---

## 10.7 Action Accuracy

类别：

```text
insert
add_source
update
pending_review
```

Exact Accuracy和混淆矩阵。

---

## 10.8 Current State Field Accuracy

读取最终真实Memory快照，分别统计：

```text
memory_type
status
task_status
blocker
progress_note
closure_reason
canonical_instance_key
family_key
assertion_key
polarity
qualifiers
```

每个字段：

```text
Accuracy = 正确字段数 / 可评分字段数
```

另输出：

```text
Memory Strict Exact
```

即一条Memory全部可评分字段均正确。

---

## 10.9 Task Binary Transition Accuracy

只计算：

```text
Existing Memory为Task
且Candidate为Task
```

使用：

```text
旧task_status
Candidate task_status
Gold最终task_status
```

预测最终Task Status与Gold一致算正确。

同时按转移分桶：

```text
todo → todo
todo → done
done → todo
done → done
```

---

## 10.10 Blocker / Progress / Closure Accuracy

分别只在对应Gold字段非空时计算Exact Accuracy。

还要统计清除行为：

```text
任务从blocked语义恢复后，旧blocker是否正确清除
Task关闭后不应保留错误progress_note
Reopen后closure_reason是否正确清除
```

建议输出：

```text
Field Set Accuracy
Field Clear Accuracy
```

---

## 10.11 Reopen Accuracy

只计算：

```text
task_reopen_valid
task_reopen_guard
```

正确条件：

### Valid

```text
Identity=same_instance
Action=update
最终task_status=todo
创建新Version
不创建PendingReview
```

### Guard

```text
Action=pending_review
正式Memory保持done
不创建正式Version
真实持久化PendingReview
```

```text
Reopen Accuracy
= 满足完整条件的Case
/ 两个Reopen分桶全部Case
```

---

## 10.12 Done Task Resolution Accuracy

只计算：

```text
done_task_without_history
```

正确条件：

```text
memory_type=task
task_status=done
closure_reason=completed
Action=insert
```

不能自动转Episodic。

---

## 10.13 Done-vs-Episodic F1

使用：

```text
done_task_without_history
episodic_without_task_identity
```

分类：

```text
task
episodic
```

计算P/R/F1和混淆矩阵。

---

## 10.14 Duplicate Active Rate

按Identity统计：

```text
同一canonical_instance_key存在多个active Memory
```

```text
Rate = 重复Active Identity数 / 全部Identity数
```

目标0。

Family相同但Instance不同，不算重复。

---

## 10.15 Stale Active Rate

已经被更新或取代的旧状态仍作为额外Active Memory存在，算Stale Active。

```text
Rate = Stale Active Memory数 / 全部最终Memory数
```

目标0。

---

## 10.16 Version Sequence Accuracy

每条Memory检查：

```text
sequence从1开始
连续递增
无重复
无空洞
顺序与Gold一致
```

按Memory计算Accuracy。

---

## 10.17 Source Link Precision / Recall / F1

比较最终Memory/Version/PendingReview的Source Ref集合。

```text
TP = Gold与Prediction Source Link交集
FP = 多连接
FN = 漏连接
```

计算微平均P/R/F1。

---

## 10.18 Antecedent Source Exact-set Accuracy

只计算：

```text
reference_source_continuity
```

Version必须同时绑定：

```text
antecedent_context Source
assertion_evidence Source
```

预测集合必须与Gold完全相同。

---

## 10.19 Pending-review Precision / Recall / F1

Case或Decision级二分类：

```text
Gold需要pending_review
Prediction是否真实持久化pending_review
```

不能只看Answer或Decision字符串。

必须数据库中存在真实记录。

---

## 10.20 Idempotence

同一Case第二次重放后比较对象数量和业务字段。

正确条件：

```text
Memory数量不变
Version数量不变
Source数量不变
PendingReview数量不变
Decision数量不变
业务字段不变
```

```text
Idempotence Accuracy
= 完整不变Case / 全部Case
```

---

## 10.21 Legacy Status Projection Accuracy

只计算：

```text
legacy_status_read_projection
```

检查：

```text
blocked / in_progress → todo
cancelled / canceled → done
```

并验证：

```text
数据库原值未被回写修改
```

投影字段：

```text
blocker
progress_note
closure_reason
legacy_task_status
```

也要按Gold核对。

---

## 10.22 Persistence Old-status Write Rate

扫描本轮新写入：

```text
Memory
Version
Candidate
```

中是否出现：

```text
blocked
in_progress
cancelled
canceled
```

```text
Rate = 旧状态新写入记录数 / 新写入Task状态记录数
```

目标0。

---

## 10.23 Optional LLM Advisory Acceptance Precision

只计算：

```text
optional_llm_identity_advisory
```

且：

```text
strong_escalation_enabled=true
LLM建议被采用
```

```text
Precision
= 被采纳且Gold确实same_instance的建议数
/ 所有被采纳建议数
```

还要报告：

```text
Advisory Invocation Rate
Acceptance Rate
Average Added Latency
```

---

## 10.24 Local Guard Veto Accuracy

统计Local Guard应拒绝的场景：

```text
无reopen证据
polarity冲突
scope冲突
多个Task实例
技术标识符冲突
```

正确条件：

```text
Guard拒绝更新
并进入new或pending_review等Gold路径
```

```text
Accuracy = 正确Veto Case / 应Veto Case
```

---

# 11. Layer 2建议验收门槛

## 硬门槛

```text
跨space写入 = 0
旧Task状态新持久化 = 0
重复Active = 0
Stale Active = 0
重复Version sequence = 0
幂等失败 = 0
伪PendingReview = 0
生产代码读取逻辑Ref/Gold = 0
执行异常 = 0
```

## 质量门槛

```text
Task Same-instance F1                 ≥ 0.98
Task Family Recall                    ≥ 0.98
Same-family Over-merge Rate           = 0
Preference Assertion Identity F1      ≥ 0.98
Preference Family Recall              ≥ 0.98
Relation Macro-F1                     ≥ 0.98
Action Accuracy                       ≥ 0.98
Current State Strict Exact            ≥ 0.95
Task Binary Transition Accuracy       ≥ 0.98
Blocker Accuracy                      ≥ 0.95
Progress Note Accuracy                ≥ 0.95
Closure Reason Accuracy               ≥ 0.98
Reopen Accuracy                       ≥ 0.98
Done Task Resolution Accuracy         = 1.00
Done-vs-Episodic Macro-F1             ≥ 0.98
Version Sequence Accuracy             ≥ 0.98
Source Link F1                        ≥ 0.98
Antecedent Source Exact-set           ≥ 0.98
Pending-review F1                     = 1.00
Idempotence                           = 1.00
Legacy Status Projection Accuracy     = 1.00
Local Guard Veto Accuracy             = 1.00
```

---

# 12. 运行顺序

不要直接运行全量。

## Layer 1

```text
1. should_store_basic
2. task_binary_status
3. task_detail_fields
4. multi_preference_split
5. multi_candidate_mixed
6. atomic_assertion_coverage
7. reference_resolution_success
8. reference_resolution_guard
9. done_task_vs_episodic
10. identity key分桶
11. noise_and_schema_guard
12. all.jsonl
```

## Layer 2

```text
1. new_task_insert
2. task_blocker_update
3. task_complete
4. task_close_noncompleted
5. task_reopen_valid
6. task_reopen_guard
7. done_task_without_history
8. episodic_without_task_identity
9. Task Identity三个分桶
10. Preference Identity两个分桶
11. reference_source_continuity
12. legacy_status_read_projection
13. optional_llm_identity_advisory
14. all.jsonl
```

当前分桶未通过时，不进入全量。

---

# 13. 结果文件要求

## Layer 1

```text
eval/results/layer1_v2_<RUN_ID>/
├── run_manifest.json
├── metrics.json
├── summary.md
├── predictions.jsonl
├── failed_cases.jsonl
├── bucket_metrics.json
├── candidate_confusion.json
├── memory_type_confusion.json
├── reference_confusion.json
├── extractor_diagnostics.json
├── schema_rejected_report.json
├── rules_recovery_report.json
├── latency_report.json
└── llm_call_report.json
```

## Layer 2

```text
eval/results/layer2_v2_<RUN_ID>/
├── run_manifest.json
├── metrics.json
├── summary.md
├── predictions.jsonl
├── failed_cases.jsonl
├── bucket_metrics.json
├── identity_confusion.json
├── relation_confusion.json
├── action_confusion.json
├── task_transition_confusion.json
├── current_state_report.json
├── source_link_report.json
├── pending_review_report.json
├── idempotence_report.json
├── legacy_projection_report.json
├── old_status_write_report.json
├── llm_advisory_report.json
├── guard_veto_report.json
└── latency_report.json
```

---

# 14. run_manifest必须记录

```text
Run ID
Git Commit SHA
Python版本
数据集Schema版本
数据集文件SHA256
后端
LLM Provider / Model
Embedding配置（即使本轮未调用也记录）
Feature Flags
Strong Escalation开关
开始与结束时间
Case数量
随机种子
并发度
```

---

# 15. 失败归因

每个失败Case只能归入一个首要原因：

## Layer 1

```text
should_store_error
clause_split_error
atom_split_error
llm_omission
rules_omission
hybrid_merge_drop
schema_rejected_error
evidence_mapping_error
memory_type_error
task_field_error
identity_key_error
preference_split_error
reference_resolution_error
antecedent_error
```

## Layer 2

```text
candidate_retrieval_error
identity_error
family_recall_error
over_merge
under_merge
relation_error
action_error
state_field_error
reopen_guard_error
done_episode_error
version_error
source_error
pending_review_error
idempotence_error
legacy_projection_error
old_status_write
llm_advisory_error
local_guard_error
repository_error
```

不能把所有失败都写成：

```text
output mismatch
```

---

# 16. 修改代码后的回归要求

本轮只允许修改：

```text
L1/L2生产逻辑
Evaluator
测试适配
数据映射代码
```

不得顺带修改：

```text
Layer 3答案Gold
Bridge/E2E Gold
用户现有PostgreSQL数据
Worker调度状态契约
Delivery状态契约
```

每次修复后至少运行：

```text
对应分桶
该层全量
现有相关pytest
```

最终还要运行完整pytest，并单独说明现有Query ReAct fallback失败是否仍然存在。

---

# 17. Codex每阶段输出格式

每次完成一个修复阶段后必须输出：

```text
1. 根因
2. 修改文件
3. 修改函数
4. 是否修改生产行为
5. 是否修改Evaluator
6. 是否修改数据集（原则上不允许）
7. 运行命令
8. 分桶结果
9. 全量结果
10. 失败Case列表
11. 关键指标变化
12. Commit SHA
13. 回滚方式
```

禁止只说：

```text
已完成
测试通过
效果明显
```

---

# 18. 最终交付条件

Layer 1完成必须同时满足：

```text
所有硬门槛通过
420 Cases完整运行
每个指标有真实分子/分母
不存在N/A被写成0或100
Prediction可复现
错误能够按阶段归因
```

Layer 2完成必须同时满足：

```text
所有硬门槛通过
400 Cases真实PostgreSQL完整运行
每Case完成正常运行、重放和只读校验
真实PendingReview持久化
新状态只产生todo/done
逻辑Ref不进入生产代码
```

---

# 19. 直接执行指令

请按以下顺序执行：

```text
第一步：
审查两套数据集Schema和当前生产模型字段，输出字段映射表。
先不要修改数据集，也不要运行全量。

第二步：
实现Layer 1 v2 Evaluator和Prediction Contract。
先运行should_store_basic、task_binary_status、multi_preference_split、
atomic_assertion_coverage、reference_resolution_success五个小集。

第三步：
补齐Layer 1所有指标，运行14个分桶。
全部分桶可执行后，再运行420条全量。

第四步：
实现Layer 2 v2 PostgreSQL隔离Seed、逻辑Ref映射、
Prediction Contract和同一Case重放。

第五步：
运行Task状态、Reopen、Done/Episodic、Task Identity、
Preference Identity、Reference Source、Legacy Projection小集。

第六步：
补齐Layer 2全部指标，运行16个分桶。
全部通过后，再运行400条PostgreSQL全量。

第七步：
输出两份独立报告。
不要运行Bridge、E2E、Layer 3或Worker全链路。

任何硬门槛失败时停止后续阶段，先修复并重新运行对应小集。
```
