# 随心记 L1→L2 真实衔接数据集 v1

- Cases：96
- 场景族：12
- Schema：`suixinji.bridge.l1_l2.v1`

用于测试：

```text
原始Note → L1 MemoryCandidate → L2 Relation/Action → Memory/Version/Source/PendingReview
```

场景分布：

```json
{
  "task_new_todo": 8,
  "task_progression": 8,
  "task_reopen": 8,
  "task_cancel_recreate": 8,
  "orphan_done_resolution": 8,
  "preference_same_add_source": 8,
  "preference_supersede": 8,
  "semantic_update": 8,
  "merge_enrichment": 8,
  "episodic_new": 8,
  "conflict_pending_review": 8,
  "multi_candidate_mixed": 8
}
```

关键规则：Task状态仅有todo/blocked/done/cancelled；Orphan Done由L2转为Episodic；m1/v1/s1/pr1只用于评测。
