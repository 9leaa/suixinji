# 随心记第一层修复数据集校验报告

## 总结

三个修复后的数据集均通过自动校验。

| 数据集 | 样本数 | 唯一输入 | 结果 |
|---|---:|---:|---|
| should_store_basic.jsonl | 120 | 120 | PASS |
| single_candidate_clean.jsonl | 160 | 160 | PASS |
| key_fields_and_status.jsonl | 180 | 180 | PASS |

## 分布

### should_store_basic

- 难度：easy 70 / medium 40 / hard 10
- 类型：preference 15 / task 15 / semantic 15 / episodic 15 / 不保存 60

### single_candidate_clean

- 难度：easy 120 / medium 40
- 类型：preference 40 / task 40 / semantic 40 / episodic 40
- 任务状态：todo 16 / blocked 8 / done 8 / cancelled 8

### key_fields_and_status

- 难度：easy 70 / medium 90 / hard 20
- 类型：preference 50 / task 70 / semantic 50 / episodic 10
- 任务状态：todo 25 / blocked 15 / done 15 / cancelled 15

## 已执行的检查

- 每行均可独立解析为 JSON
- 顶层和 Candidate 字段严格匹配
- case_id 与 note_id 一致
- classification 和 hints 使用固定结构
- evidence_span 是原文连续片段
- entities 均能在原文中找到
- old_value/new_value 有原文依据
- 非 Task 的 task_status 为 null
- 不存在 in_progress
- Candidate 数量符合各数据集约束
- 不存在重复输入文本
- content 未直接拼接状态枚举
- 难度、类型和任务状态分布符合规范

## 关键修复

1. Preference 的 new_value 统一保存偏好主题，不再保存 positive/negative。
2. 修复“在某地工作”被误标为居住地等 Semantic 错误。
3. 修复从原文无法推出的 Task operation。
4. 删除单候选基础集中的模糊指代。
5. 修复 entities 不是原文子串的问题。
6. 调整难度分布，并将升级样本改写为真实的中高难度表达。
