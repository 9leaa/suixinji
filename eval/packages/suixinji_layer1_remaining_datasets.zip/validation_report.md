# 随心记第一层剩余数据集校验报告

- 全部通过：`True`

## multi_candidate

- 样本数：120
- 唯一消息：120
- Candidate 数量分布：`{2: 60, 3: 40, 4: 10, 5: 10}`
- 难度分布：`{'easy': 40, 'medium': 60, 'hard': 20}`
- Memory 类型分布：`{'preference': 82, 'task': 82, 'semantic': 83, 'episodic': 83}`
- Task 状态分布：`{'todo': 21, 'blocked': 21, 'done': 20, 'cancelled': 20}`
- 校验结果：`PASS`

## hard_language_and_noise

- 样本数：150
- 唯一消息：150
- Candidate 数量分布：`{0: 30, 1: 60, 2: 40, 3: 20}`
- 难度分布：`{'hard': 120, 'medium': 30}`
- Memory 类型分布：`{'preference': 50, 'task': 50, 'semantic': 50, 'episodic': 50}`
- Task 状态分布：`{'todo': 14, 'blocked': 13, 'done': 12, 'cancelled': 11}`
- 校验结果：`PASS`
