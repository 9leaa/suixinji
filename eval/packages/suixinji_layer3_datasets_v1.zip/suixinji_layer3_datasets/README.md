# 随心记 Layer 3：检索与最终回答评测数据集

## 1. 第三阶段测什么

第三阶段从已经持久化的 `Memory / Version / Source` 快照开始，评测：

```text
用户 Query
→ 查询路由
→ Memory / Version 召回
→ 排序与去旧
→ 答案生成
→ Source 引用
```

它不重新调用第一阶段抽取器，也不重新执行第二阶段状态演化。

## 2. 数据集组成

| 文件 | Cases | 主要能力 |
|---|---:|---|
| `current_state_retrieval.jsonl` | 120 | 当前偏好、任务、事实和最近事件 |
| `history_and_temporal.jsonl` | 100 | 历史版本、状态变化与时间问题 |
| `semantic_paraphrase_and_noise.jsonl` | 100 | 改写、错别字、中英混合、间接指代 |
| `no_answer_conflict_and_stale.jsonl` | 100 | 无答案、过期记忆、冲突、权限与歧义 |
| `multi_memory_answer_and_citation.jsonl` | 100 | 多 Memory 聚合、时间线与逐 Claim 引用 |

总计：**520 Cases**。

## 3. 核心指标

### 检索指标

- `Recall@1 / @3 / @5 / @10`
- `Precision@1 / @3 / @5 / @10`
- `MRR`
- `nDCG@10`
- `Current Hit Rate`
- `History Hit Rate`
- `Stale Hit Rate`

### 回答指标

- `Query Answer Accuracy`
- `Claim Precision / Recall / F1`
- `No-answer Precision / Recall / F1`
- `Source Citation Precision / Recall / F1`
- `Citation Exact-set Accuracy`

### 辅助诊断

- `Query Route Accuracy`
- 按 Memory Type、查询类型和 coverage tag 分桶
- 当前状态问题与历史问题分别报告
- 无答案、冲突、敏感权限和歧义分别报告

## 4. 关键评测原则

1. 当前状态问题不能使用已过期或 `superseded` Memory 作为当前答案。
2. 历史问题必须允许召回 Version，不能只搜索 Active Memory。
3. `no_answer=true` 时，不允许根据无关记忆猜测答案。
4. 冲突问题应回答“存在冲突/无法确认”，不能武断选择一方。
5. 每条事实性 Claim 必须追溯到正确 Source。
6. 敏感记忆必须遵守 `access_context`。
7. 自动评分优先使用 Claim 级别匹配，不建议只比较整句字符串。

## 5. 推荐验收门槛

| 指标 | 建议门槛 |
|---|---:|
| Recall@3 | ≥ 95% |
| Recall@5 | ≥ 98% |
| MRR | ≥ 0.90 |
| nDCG@10 | ≥ 0.95 |
| Current Hit Rate | ≥ 98% |
| History Hit Rate | ≥ 95% |
| Stale Hit Rate | ≤ 1%，目标 0% |
| No-answer F1 | ≥ 95% |
| Query Answer Accuracy | ≥ 90% |
| Claim F1 | ≥ 95% |
| Citation F1 | ≥ 98% |
| Sensitive access violations | 0 |
| Cross-space retrieval violations | 0 |

## 6. Schema

每条 Case 包含：

```json
{
  "schema_version": "suixinji.layer3.retrieval_answer.v1",
  "case_id": "l3_current_001",
  "dataset": "current_state_retrieval",
  "difficulty": "easy",
  "input": {
    "space_id": "space_l3_current_001",
    "query": "我现在住在哪里？",
    "query_time": "2026-08-03T00:00:00Z",
    "top_k": 10,
    "access_context": {
      "requester": "owner",
      "allow_sensitive": true
    },
    "memory_snapshot": {
      "memories": [],
      "versions": [],
      "sources": [],
      "pending_reviews": []
    }
  },
  "expected": {
    "expected_route": "structured",
    "answer_type": "current_state",
    "relevant_current_refs": ["m1"],
    "relevant_history_refs": [],
    "graded_relevance": {"m1": 3},
    "must_not_return_refs": ["m2"],
    "expected_claims": [],
    "canonical_answer": "你目前居住在杭州。",
    "no_answer": false,
    "required_citation_refs": ["s1"],
    "forbidden_claims": []
  },
  "coverage_tags": ["current_state", "semantic", "location"]
}
```

## 7. 字段说明

- `memory_ref / version_ref / source_ref`：Case 内逻辑引用，运行时映射为真实数据库 ID。
- `graded_relevance`：建议使用 3=核心答案，2=重要历史证据，1=辅助信息。
- `must_not_return_refs`：不应召回的无关、过期或越权对象。
- `expected_claims`：用于 Claim 级答案评分及逐 Claim 引用检查。
- `canonical_answer`：方便人工核查，不建议作为唯一自动评分标准。
- `expected_route`：辅助指标，不应替代最终检索和回答指标。
- `forbidden_claims`：答案中不得出现的武断结论、越权内容或过期事实。

## 8. 推荐执行顺序

```text
1. 将 Case 中的 Memory / Version / Source 写入独立测试 Space
2. 使用生产查询入口执行 Query
3. 保存原始召回列表、排序分数、路由和最终答案
4. 映射数据库 UUID 到逻辑 ref
5. 分别计算检索指标、回答指标和引用指标
6. 清理测试 Space
```

建议保留：

```text
layer3_metrics.json
layer3_predictions.jsonl
layer3_failed_cases.jsonl
layer3_retrieval_breakdown.json
layer3_no_answer_report.json
layer3_citation_report.json
layer3_route_confusion.json
```
