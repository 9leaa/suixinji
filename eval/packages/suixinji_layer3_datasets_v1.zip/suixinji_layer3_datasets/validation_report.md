# Layer 3 数据集校验报告

- Schema：`suixinji.layer3.retrieval_answer.v1`
- 总 Cases：520
- 校验错误：0

| Dataset | Cases |
|---|---:|
| `current_state_retrieval` | 120 |
| `history_and_temporal` | 100 |
| `semantic_paraphrase_and_noise` | 100 |
| `no_answer_conflict_and_stale` | 100 |
| `multi_memory_answer_and_citation` | 100 |

全部 Case 通过结构与逻辑引用完整性校验。
