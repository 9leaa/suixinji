#!/usr/bin/env python3
import argparse, gzip, json

def rows(path):
    with gzip.open(path, 'rt', encoding='utf-8') as f:
        for line_no, line in enumerate(f, 1):
            obj = json.loads(line)
            if line_no == 1 and obj.get('record_type') == 'metadata':
                continue
            yield obj

def main():
    p = argparse.ArgumentParser()
    p.add_argument('path')
    p.add_argument('--suite')
    p.add_argument('--split')
    p.add_argument('--limit', type=int)
    args = p.parse_args()
    n = 0
    for case in rows(args.path):
        if args.suite and case.get('suite') != args.suite:
            continue
        if args.split and case.get('split') != args.split:
            continue
        print(json.dumps(case, ensure_ascii=False))
        n += 1
        if args.limit and n >= args.limit:
            break

if __name__ == '__main__':
    main()
