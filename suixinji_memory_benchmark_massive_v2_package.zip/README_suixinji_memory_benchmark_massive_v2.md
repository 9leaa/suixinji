# Suixinji Massive Memory Benchmark V2

## Files

- `suixinji_memory_benchmark_massive_v2_210k.jsonl.gz`: 210,000 cases, streaming JSONL compressed with gzip.
- `suixinji_memory_benchmark_massive_v2_manifest.json`: counts, checksum, schema and coverage.
- `suixinji_memory_benchmark_massive_v2_sample_300.json`: first 300 cases in readable JSON.
- `load_suixinji_massive_benchmark.py`: streaming loader and suite/split filter.

## Main-file format

The first JSONL row is metadata. Every following row is one independent case.

Each case contains:

- `suite`, `split`, `difficulty`, `tags`
- `timeline`: source notes and extraction gold labels
- `query`: optional query and expected route
- `expected`: suite-specific gold labels, including candidates, actions, retrieval IDs, lifecycle state and safety constraints

## Recommended evaluation groups

1. Extraction: Precision / Recall / F1 by memory type, false-memory rate, evidence-span validity.
2. Relation adjudication: Macro-F1 for new/same/merge/update_task/supersede/conflict and destructive-action error rate.
3. Evolution: active-state accuracy, stale/duplicate task rates, source/version preservation.
4. Retrieval: Recall@1/@3/@5/@10, MRR, nDCG, deleted/stale leakage and cross-space leakage.
5. Routing: simple/complex accuracy, complex precision/recall/F1, expansion coverage, false-complex rate.
6. Performance: planner, retrieval, extraction and end-to-end P50/P95/P99 measured separately.

## Important limitation

This is a deterministic synthetic stress dataset. It is suitable for regression, adversarial coverage and load-oriented evaluation. It must not be presented as production traffic quality or live-LLM quality without a separate human-reviewed and online evaluation set.
